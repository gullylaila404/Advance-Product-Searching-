from models import Product

# Create a test product
test_product = Product(1, "Test Product", "Test Brand", 1000, "In Stock", "Test Description", "Test Category", 5)
print(test_product) 